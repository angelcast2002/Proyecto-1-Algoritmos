/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.algoproyectojunits1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Angel
 */
public class InterpreteTest {
    
    public InterpreteTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of ejecutar method, of class Interprete.
     */
    @Test
    public void testWrite() {
        Interprete interprete = new Interprete();
        String evaluar = interprete.Evaluar("(write 'hola)");
        assertEquals(evaluar, "");
    }

    @Test
    public void testSetQ() {
        Interprete interprete = new Interprete();
        String evaluar = interprete.Evaluar("(setq curso 'algoritmos)");
        assertEquals(evaluar, "");
    }

    /*
     * LISTAS
     */
    @Test
    public void testFirst() {
        Interprete interprete = new Interprete();
        String evaluar = interprete.Evaluar("(first '(a b c)");
        assertEquals(evaluar, "");
    }

    /*
     * FUNCIONES
     */
    @Test
    public void testDefun() {
        Interprete interprete = new Interprete();
        String evaluar = interprete.Evaluar("(defun sum '((a b) (+ a b)))");
        assertEquals(evaluar, "");
    }

    /*
     * CONDICIONALES
     */
    @Test
    public void testEcuals() {
        Interprete interprete = new Interprete();
        String evaluar = interprete.Evaluar("(ecuals 1 1)");
        assertEquals(evaluar, "");
    }

    @Test
    public void testNumberp() {
        Interprete interprete = new Interprete();
        String evaluar = interprete.Evaluar("(numberp 'b)");
        assertEquals(evaluar, "");
    }

    /*
     * PREDICADOS
     */
    @Test
    public void testEval() {
        Interprete interprete = new Interprete();
        String evaluar = interprete.Evaluar("(eval (+ 1 6))");
        assertEquals(evaluar, "");
    }

    @Test
    public void testOperaciones() {
        Interprete interprete = new Interprete();
        String evaluar = interprete.Evaluar("(+ 1 7)");
        assertEquals(evaluar, "");
    }
    
}
